﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace KRStore
{
    public class DatabaseHelper
    {
        private const string ConnectionString = "Data Source=KRStoreDatabase.db;Version=3;";

        public static void InitializeDatabase()
        {
            using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                // Пример создания таблицы Users
                string createUserTableQuery = "CREATE TABLE IF NOT EXISTS Users (Id INTEGER PRIMARY KEY AUTOINCREMENT, Username TEXT, Password TEXT);";
                using (SQLiteCommand command = new SQLiteCommand(createUserTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                // Создаем таблицу Purchases
                string createPurchasesTableQuery = "CREATE TABLE IF NOT EXISTS Purchases (Id INTEGER PRIMARY KEY AUTOINCREMENT, UserId INTEGER, PurchaseDate TEXT, Price REAL);";
                using (SQLiteCommand command = new SQLiteCommand(createPurchasesTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public static bool CreateUser(string username, string password)
        {
            using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                if (UserExists(username))
                {
                    Console.WriteLine($"Ошибка: Пользователь с именем {username} уже существует.");
                    return false;
                }

                string insertUserQuery = "INSERT INTO Users (Username, Password) VALUES (@Username, @Password);";
                using (SQLiteCommand command = new SQLiteCommand(insertUserQuery, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool ValidateUser(string username, string password)
        {
            using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string validateUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password;";
                using (SQLiteCommand command = new SQLiteCommand(validateUserQuery, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    return (long)command.ExecuteScalar() > 0;
                }
            }
        }

        public static bool RegisterUser(string username, string password)
        {
            bool registrationResult = CreateUser(username, password);
            if (!registrationResult)
            {
                Console.WriteLine($"Ошибка при регистрации пользователя {username}");
            }

            return registrationResult;
        }

        public static bool UserExists(string username)
        {
            using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string userExistsQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username;";
                using (SQLiteCommand command = new SQLiteCommand(userExistsQuery, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    return (long)command.ExecuteScalar() > 0;
                }
            }
        }

        public static void AddPurchaseToUser(string username, Purchase purchase)
        {
            using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                int userId = GetUserId(username, connection);

                if (userId > 0)
                {
                    string addPurchaseQuery = "INSERT INTO Purchases (UserId, PurchaseDate, Price) VALUES (@UserId, @PurchaseDate, @Price);";
                    using (SQLiteCommand command = new SQLiteCommand(addPurchaseQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", userId);
                        command.Parameters.AddWithValue("@PurchaseDate", purchase.PurchaseDate);
                        command.Parameters.AddWithValue("@Price", purchase.Price);

                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        private static int GetUserId(string username, SQLiteConnection connection)
        {
            string getUserIdQuery = "SELECT Id FROM Users WHERE Username = @Username;";
            using (SQLiteCommand command = new SQLiteCommand(getUserIdQuery, connection))
            {
                command.Parameters.AddWithValue("@Username", username);

                object result = command.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
    }
}