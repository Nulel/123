﻿using System;
using System.Collections.Generic;
using System.IO;

namespace KRStore
{
    public class Product
    {
        public string Name { get; set; }
        public string Price { get; set; }
        public string ImageFileName { get; set; }
        public List<Purchase> Purchases { get; set; } = new List<Purchase>();

        // Новое свойство для получения полного пути к изображению
        public override string ToString()
        {
            return $"{Name} - {Price}";
        }

        // Новое свойство для отслеживания количества товара в корзине
        public int QuantityInCart { get; set; }
    }
}