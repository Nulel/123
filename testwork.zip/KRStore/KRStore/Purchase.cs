﻿using System;

namespace KRStore
{
    public class Purchase
    {
        public int Id { get; set; }
        public DateTime PurchaseDate { get; set; }
        public double Price { get; set; }
    }
}