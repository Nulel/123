﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KRStore
{
    public partial class ProductsForm : Window
    {
        private List<Product> products;

        public ProductsForm()
        {
            InitializeComponent();
            InitializeProducts();
            DisplayProducts();
        }
        private void InitializeProducts()
        {
            products = new List<Product>
    {
        new Product { Name = "CS 2", Price = "$10", ImageFileName = "0N9DwfKb1t7vdXJm4H4inH1tQU4YQ2UMoli5iGdwA6pPdLmESAw3vgJxDWDuWC-0-EKdD5r3mmwN0JrBn2GZu-ft.jpg" },
        new Product { Name = "Dota 2", Price = "$15", ImageFileName = "zGkHuA-ZnkVh6wI68D40g8Z_rEGQlNqVt4McvarWjCLRoKnTn637ImJGCoTQ2Wz2SBhMdwhe.jpg" },
        new Product { Name = "The last of us", Price = "$150", ImageFileName = "i.jpg" },
        new Product { Name = "The last of us 2", Price = "$30", ImageFileName = "cybere1042f1ec68.jpg" },
        new Product { Name = "GTA 6", Price = "$80", ImageFileName = "NUN4V7BrBh4nxvLQlJstWw.jpeg" }
    };
        }

        private void DisplayProducts()
        {
            productsListBox.ItemsSource = products;
        }

        private void AddToCartButton_Click(object sender, RoutedEventArgs e)
        {
            if (productsListBox.SelectedItem != null)
            {
                Product selectedProduct = (Product)productsListBox.SelectedItem;
                Cart.Instance.AddToCart(selectedProduct);
                MessageBox.Show($"Product added to cart: {selectedProduct.Name}");
            }
        }

        private void ViewCartButton_Click(object sender, RoutedEventArgs e)
        {
            CartForm cartForm = new CartForm();
            this.Hide();
            cartForm.ShowDialog();
            this.Close();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            this.Hide();
            loginForm.ShowDialog();
            this.Close();
        }
    }
}