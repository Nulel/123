﻿using System.Collections.Generic;
using System.Windows;

namespace KRStore
{
    public partial class CartForm : Window
    {
        public CartForm()
        {
            InitializeComponent();
            DisplayCart();
        }

        private void DisplayCart()
        {
            cartListBoxControl.ItemsSource = Cart.Instance.GetCartItems();
        }
        private void RemoveFromCartButton_Click(object sender, RoutedEventArgs e)
        {
            if (cartListBoxControl.SelectedItem != null)
            {
                CartItem selectedItem = (CartItem)cartListBoxControl.SelectedItem;
                Cart.Instance.RemoveFromCart(selectedItem);
                MessageBox.Show($"Product removed from cart: {selectedItem.Product.Name}");
                DisplayCart();
            }
        }
        private void CheckoutButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Order placed. Thank you!");
            Cart.Instance.ClearCart();
            DisplayCart();
        }

        private void BackToProductsButton_Click(object sender, RoutedEventArgs e)
        {
            ProductsForm productsForm = new ProductsForm();
            this.Hide();
            productsForm.ShowDialog();
            this.Close();
        }
    }
}
