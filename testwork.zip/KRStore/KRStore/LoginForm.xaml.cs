﻿using System;
using System.Windows;

namespace KRStore
{
    public partial class LoginForm : Window
    {
        public LoginForm()
        {
            try
            {
                InitializeComponent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception in LoginForm constructor: {ex.Message}");
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя и пароль.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (DatabaseHelper.ValidateUser(username, password)) // Внесены изменения здесь
                {
                    MessageBox.Show("Вход успешно выполнен!");
                    OpenProductsForm();
                }
                else
                {
                    MessageBox.Show("Введены неверные данные.");
                }
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordBox.Password;
            string confirmPassword = confirmPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Пожалуйста Введите данные, для регистрации.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (UserExists(username))
            {
                MessageBox.Show("Пользователь с таким именем уже существует.");
            }
            else if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
            }
            else
            {
                // Внесены изменения здесь
                if (DatabaseHelper.RegisterUser(username, password))
                {
                    MessageBox.Show("Регистрация успешна!");
                    OpenProductsForm();
                }
                else
                {
                    MessageBox.Show("Ошибка при регистрации.");
                }
            }
        }

        private bool IsValidUser(string username, string password)
        {
            return username == "user" && password == "password";
        }

        private bool UserExists(string username)
        {
            return DatabaseHelper.UserExists(username);
        }

        private void OpenProductsForm()
        {
            ProductsForm productsForm = new ProductsForm();
            this.Hide();
            productsForm.ShowDialog();
            this.Close();
        }
    }
}