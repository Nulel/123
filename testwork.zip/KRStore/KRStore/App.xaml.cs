﻿using System.Windows;

namespace KRStore
{
    public partial class App : Application
    {
        private static bool isLoginFormOpened = false;
        private static readonly object lockObject = new object();

        private void App_Startup(object sender, StartupEventArgs e)
        {
            DatabaseHelper.InitializeDatabase();

            // Используем lock для синхронизации доступа к переменной isLoginFormOpened
            lock (lockObject)
            {
                // Открываем главное окно только если оно еще не открыто и это старт приложения
                if (!isLoginFormOpened && e.Args.Length == 0)
                {
                    LoginForm loginForm = new LoginForm();
                    loginForm.Show();
                    isLoginFormOpened = true;
                }
            }
        }
    }
}
