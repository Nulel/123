﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KRStore
{
    public class CartItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
        public string DisplayText => Product?.Name;
    }

    public class Cart
    {
        private static Cart _instance;
        public static Cart Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Cart();
                }
                return _instance;
            }
        }

        private List<CartItem> cartItems;

        private Cart()
        {
            cartItems = new List<CartItem>();
        }

        public void AddToCart(Product product)
        {
            CartItem existingItem = cartItems.Find(item => item.Product == product);
            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                cartItems.Add(new CartItem { Product = product, Quantity = 1 });
            }
        }

        public void RemoveFromCart(CartItem cartItem)
        {
            if (cartItems.Contains(cartItem))
            {
                if (cartItem.Quantity > 1)
                {
                    cartItem.Quantity--;
                }
                else
                {
                    cartItems.Remove(cartItem);
                }
            }
        }

        public List<CartItem> GetCartItems()
        {
            return new List<CartItem>(cartItems);
        }

        public void ClearCart()
        {
            cartItems.Clear();
        }
    }
}