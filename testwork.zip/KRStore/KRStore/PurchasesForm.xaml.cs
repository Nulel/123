﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KRStore
{
    /// <summary>
    /// Логика взаимодействия для PurchasesForm.xaml
    /// </summary>
    public partial class PurchasesForm : Window
    {
        private User currentUser;

        public PurchasesForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            DisplayPurchases();
        }

        private void DisplayPurchases()
        {
            purchasesListBox.ItemsSource = currentUser.Purchases;
        }
    }
}
